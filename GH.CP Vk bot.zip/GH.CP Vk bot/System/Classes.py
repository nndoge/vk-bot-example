class info:
	Name = "GH.CP Attachments"
	Developer = "Max Stewart"
	Version = "1.01"
	Coding = 'utf-8'
	ChangeLog ={
		'V1.00 (20.12.2019) - Created.'
		'V1.01 (24.12.2019) - Added advertisement.'
	}