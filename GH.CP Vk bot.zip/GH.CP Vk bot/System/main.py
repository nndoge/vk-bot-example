import vk_api
from vk_api.longpoll import VkLongPoll, VkEventType
import os
import sys
import datetime
import random
import webbrowser
import re
import platform
from time import sleep
import Classes
import wget
import main
print(webbrowser.get())
print(main)

class V:
	STARTING = "Server is starting up..."
	RUNNING = "Server is running"
	IMPORTS = "import vk_api\nimport sys\nimport os\nimport random\nfrom vk_api.longpoll import VkLongPoll, VkEventType\nimport datetime"
	SEND = "<request_send>"
	RETURN = "Returned"
	NAME_ERROR = "NameError In write_msg()"
	SYNTAX_ERROR = "SyntaxError In write_msg()"
	NOT_UNDERSTEND = "Неверная команда. Напиши \"Помощь\". "
	HELP = "Привет. Вот список команд:\n/time - вывести текущее время.\n"
	TIME = "Время(server): "
	RECEIVED = "<request_received>"
	ADS = "Transition to advertising..."
	URL = "https://vk.com/maxstew.developq"
	PRIZE = "Thanks for watching the ad!"
	
def write_msg(user_id, message):
	vk.method('messages.send', {'user_id': user_id, 'message': message})
	
	
def println(error, msg):
	if error == "y":
		print("[ERROR] ", msg)
	elif error == "n":
		print("[INFO] ", msg)
	else:
		print(msg)
y = "y"
n = "n"

def httpsOpen(time, url):
	sleep(time)
	webbrowser.get().open_new_tab(url)

SystemName = platform.system()
if SystemName == 'Windows':
	def Clear():
		os.system('cls')
else:
	def Clear():
		os.system('clear')
print()
try:
	f = open("token.txt", "r")
	token = f.read()
except:
	print("Token not found, please run __Init__.py to reinstall program.")
	quit()
if token == "":
	print("Token not found")
	quit()

print(Classes.info.Name + " " + Classes.info.Version)
println(n, V.STARTING)
println(n, V.ADS)
httpsOpen(2, V.URL)
println(n, V.PRIZE)



vk = vk_api.VkApi(token = token, api_version = '5.89')

println(n, V.RUNNING)


longpoll = VkLongPoll(vk)
random_id = int(64)

for event in longpoll.listen():
	if event.type == VkEventType.MESSAGE_NEW:
		req = event.text
		user = event.user_id
		if event.to_me:
			try:
				if req == "_imports_":
					println(n, V.RECEIVED)
					write_msg(user, V.IMPORTS)
					println(n, V.SEND)
				elif req == "return 1":
					println(n, V.RECEIVED)
					println(n, V.RETURN)
					quit()
				elif req == "Помощь":
					println(n, V.RECEIVED)
					write_msg(user, V.HELP)
					println(n, V.SEND)
				elif req == "помощь":
					println(n, V.RECEIVED)
					write_msg(user, V.HELP)
					println(n, V.SEND)
				elif req == "/time":
					println(n, V.RECEIVED)
					now = datetime.datetime.now()
					write_msg(user, V.TIME + str(now.strftime("%H:%M")))
					println(n, V.SEND)
				else:
					println(n, V.RECEIVED)
					write_msg(user, V.NOT_UNDERSTEND)
					println(n, V.SEND)
			except NameError:
				println(n, V.NAME_ERROR)
				quit()
			except SyntaxError:
				println(y, V.SYNTAX_ERROR)
				quit()